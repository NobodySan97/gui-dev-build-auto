--pretranslated: do not change this file
 
-- Enable localization

local content_helper = require("web.content_helper")
local session = ngx.ctx.session

local cui = {
    advanced = "uci.web.uiconfig.@uidefault.alwaysadvanced",
	gui_skin = "uci.modgui.gui.gui_skin",
	gui_version = "rpc.system.modgui.gui_version",
	gui_animation = "uci.modgui.gui.gui_animation",
}
content_helper.getExactContent(cui)

ngx.print('\
<!DOCTYPE HTML>\
');  ngx.print( string.format('<html lang="%s">', gettext.language()) ); ngx.print('\
  <head>\
    <title>');  ngx.print( T"Gateway" ); ngx.print('</title>\
    <meta http-equiv="X-UA-Compatible" content="IE=edge">\
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">\
    <meta charset="UTF-8">\
    <meta name="CSRFtoken" content="');  ngx.print( session:getCSRFtoken() ); ngx.print('">\
    <meta name="Advanced" content="');  ngx.print( cui.advanced ); ngx.print('">\
	<link rel="preload" href="/css/gw.css?v=1788177500&version='); ngx.print(cui.gui_version); ngx.print('" as="style">\
	<link href="/css/font-awesome-all-5.7.2.css?v=1788177500&version='); ngx.print(cui.gui_version); ngx.print('" rel="stylesheet">\
    <link href="/css/gw.css?v=1788177500&version='); ngx.print(cui.gui_version); ngx.print('" rel="stylesheet">\
    <link href="/css/responsive.css?v=1788177500&version='); ngx.print(cui.gui_version); ngx.print('" rel="stylesheet">\
	<link id="theme_skin" rel="stylesheet" href="/theme/');  ngx.print( cui.gui_skin ); ngx.print('/style.css?v=1788177500&version='); ngx.print(cui.gui_version); ngx.print('">\
	<link rel="shortcut icon"    type="image/x-icon"   href="/img/favicon.ico"    />')
	if cui.gui_animation == "1" then
		ngx.print('<link rel="stylesheet" href="/css/aos.css?v=1788177500&version='); ngx.print(cui.gui_version); ngx.print('" >')
	end
	ngx.print('\
	<script src="/js/jquery.min.js?v=1788177500&version='); ngx.print(cui.gui_version); ngx.print('" ></script>\
	<script src="/js/main-min-nojquery.js?v=1788177500&version='); ngx.print(cui.gui_version); ngx.print('" defer></script>\
	<script src="/js/knockout-min.js?v=1788177500&version='); ngx.print(cui.gui_version); ngx.print('" defer></script>')
	if cui.gui_animation == "1" then
		ngx.print('<script src="/js/aos.js?v=1788174128&version='); ngx.print(cui.gui_version); ngx.print('" defer></script>')
	end
	ngx.print('\
	<script src="/js/Chart.min.js?v=1788174128&version='); ngx.print(cui.gui_version); ngx.print('" defer></script>\
	<script async src="/js/srp-min.js?v=1788174128&version='); ngx.print(cui.gui_version); ngx.print('" ></script>');
	local script_file_presence = content_helper.fileExists(string.format("/www/docroot/theme/%s/script.js", cui.gui_skin))
	if script_file_presence then
		ngx.print('<script src="/theme/');  ngx.print( cui.gui_skin ); ngx.print('/script.js?v=1788174128&version='); ngx.print(cui.gui_version); ngx.print('" defer></script>');
	end
ngx.print('\
  </head>\
')