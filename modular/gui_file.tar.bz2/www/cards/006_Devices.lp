--pretranslated: do not change this file
 
-- Enable localization
gettext.textdomain('webui-core')

local format = string.format
local tonumber = tonumber

local lfs = require("lfs")
local table = table
local ui_helper = require("web.ui_helper")
local content_helper = require("web.content_helper")
local proxy = require("datamodel")
local format, find, sub, match = string.format, string.find, string.sub, string.match

-- Devices data
local devices_data = {
  numWireless = "sys.hosts.ActiveWirelessNumberOfEntries",
  numEthernet = "sys.hosts.ActiveEthernetNumberOfEntries",
}
content_helper.getExactContent(devices_data)

local modalPath = nil
local switchName = nil
local modal_link = ""
local wireless_modal_link = ""
local traffic_monitor_link = ""
local session = ngx.ctx.session
if session:hasAccess("/modals/device-modal.lp") then
  modalPath = "/modals/device-modal.lp"
  modal_link='class="modal-link" data-toggle="modal" data-remote="/modals/device-modal.lp" data-id="device-modal"'
  wireless_modal_link='class="modal-link" data-toggle="modal" data-remote="/modals/wifi-nurse-modal.lp" data-id="device-modal"'
  traffic_monitor_link='class="modal-link" data-toggle="modal" data-remote="/modals/traffic-monitor.lp" data-id="device-modal"'
end
  ngx.print('\
\
<div class="span3">\
  <div class="smallcard" data-aos="zoom-in" data-aos-anchor-placement="center-bottom" data-aos-easing="ease-in-back">\
    ');  ngx.print( ui_helper.createCardHeader(T"Devices", modalPath, switchName, nil)  ); ngx.print('\
    <div class="content card_bg" data-bg-text="&#xf1e6;">\
	<div class="divtable">\
      ');  local nHot = 0
        local all_stations = proxy.get("rpc.wireless.ap.@.station.")
        if all_stations then
          for _, entry in ipairs(all_stations) do
            if entry.param == "state" and entry.value == "Authenticated Associated" then
              nHot = nHot + 1
            end
          end
        end
        local nEth = tonumber(devices_data["numEthernet"]) or 0
        local nWiFi = tonumber(devices_data["numWireless"]) or 0
        ngx.print(
            '<p class="subinfos">',
            '<i class="fas fa-link fa-fw" aria-hidden="true"></i>&nbsp;',
            format( N('<strong id = "Ethernet_Devices" %1$s>%2$d Ethernet device</strong> connected',
                      '<strong id = "Ethernet_Devices" %1$s>%2$d Ethernet devices</strong> connected', nEth),
                      modal_link, nEth),
            '</p>',
            '<p class="subinfos">',
            '<i class="fas fa-wifi fa-fw" aria-hidden="true"></i>&nbsp;',
            format( N('<strong id = "Wifi_Devices" %1$s>%2$d Wi-Fi device</strong> connected',
                      '<strong id = "Wifi_Devices" %1$s>%2$d Wi-Fi devices</strong> connected', nWiFi),
                      wireless_modal_link, nWiFi),
			'</p>',
			'<p class="subinfos">',
				'<i class="fas fa-chart-line fa-fw" aria-hidden="true"></i>&nbsp;',
				format( '<strong id = "Traffic_Monitor" %1$s>%s</strong>', traffic_monitor_link, T"Traffic Monitor"),
				--'<div data-toggle="modal" data-remote="/modals/diagnostics-xdsl-graphics-modal.lp" data-id="iagnostics-xdsl-graphics-modal">',
				--	,T("Traffic Monitor"),
				--'</div>',
            '</p>'
        )
        if lfs.attributes("/etc/config/hotspot", "mode") == "file" then  ngx.print('                                     \
           <p class="subinfos">                                                             \
           ');  
           ngx.print(format( N('<strong id = "Ethernet_Devices" %1$s>%2$d Hotspot device</strong> connected',             
                               '<strong id = "Ethernet_Devices" %1$s>%2$d Hotspot devices</strong> connected', nHot),     
                                modal_link, nHot))
             ngx.print('\
           </p>\
        ');  end  ngx.print('\
    </div>\
	</div>\
  </div>\
</div>\
'); 
