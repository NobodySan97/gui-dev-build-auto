local json = require("dkjson")
local proxy = require("datamodel")
local ngx = ngx

local data = {}

local commandstatus = proxy.get("rpc.system.modgui.executeCommand.state")
local raw_state = commandstatus and commandstatus[1] and commandstatus[1].value
if not raw_state or raw_state == "Idle" or raw_state == "Mapper Error" then
	local f = io.open("/tmp/executeCommandRes", "r")
	if f then
		local disk_state = f:read("*all")
		f:close()
		if disk_state and disk_state ~= "" then
			raw_state = disk_state:gsub("^%s+", ""):gsub("%s+$", "")
		end
	end
end
data["state"] = raw_state or "Idle"

local action = { 
	Checking = function()
		local data = {}
		local new_ver = proxy.get("uci.modgui.gui.new_ver")
		if new_ver and new_ver[1] and new_ver[1].value and new_ver[1].value ~= "" then
			data["new_version_text"] = new_ver[1].value
		end
		local outdated = proxy.get("uci.modgui.gui.outdated_ver")
		if outdated and outdated[1] and outdated[1].value and outdated[1].value ~= "" then
			data["outdated_ver"] = outdated[1].value
		end
		return data
	end,
}

local untaint = string.untaint or function(s) return s end

if action[untaint(data.state)] then 
	for key, val in pairs(action[untaint(data.state)]()) do
		data[key] = val
	end

else
	if ngx.req and ngx.req.get_uri_args and ngx.req.get_uri_args().auto_update == "true" then
		local new_ver = proxy.get("uci.modgui.gui.new_ver")
		if new_ver and new_ver[1] and new_ver[1].value and new_ver[1].value ~= "" then
			data["new_version_text"] = new_ver[1].value
		end
		local outdated = proxy.get("uci.modgui.gui.outdated_ver")
		if outdated and outdated[1] and outdated[1].value and outdated[1].value ~= "" then
			data["outdated_ver"] = outdated[1].value
		end
	end
	local file = io.open("/tmp/command_log","r")
	if file then
		local content = file:read('*a')
		file:close()
		-- CLI progress rewrites the current line with a carriage return.
		-- Normalize it before the multistage upgrade reporting sees it.
		content = (content or ""):gsub("\r\n", "\n"):gsub("[^\r\n]*\r", "")
		local last_pct = nil
		for p in content:gmatch("(%d+%.?%d*)%%") do
			last_pct = p
		end
		if last_pct then
			data["progress"] = tonumber(last_pct)
		end
		-- Strip curl progress bar artifacts and ANSI escape sequences
		local clean_lines = {}
		for line in content:gmatch("[^\r\n]+") do
			local sanitized = line:gsub("\27%[[0-9;]*[a-zA-Z]", ""):gsub("\27%[[0-9;]*m", "")
			local stripped = sanitized:gsub("^[%s#=%-O]*%d+%.?%d*%%[%s#=%-O]*", ""):gsub("^[%s#=%-O]+$", ""):gsub("^%s+$", "")
			if stripped ~= "" then
				clean_lines[#clean_lines + 1] = stripped
			end
		end
		if #clean_lines == 0 and data["progress"] then
			clean_lines[1] = string.format("[Download] Download in corso... %d%%", math.floor(data["progress"]))
		end
		-- Keep only the most recent 80 lines for fast JSON serialization and UI rendering
		if #clean_lines > 80 then
			local truncated = {}
			for i = #clean_lines - 79, #clean_lines do
				truncated[#truncated + 1] = clean_lines[i]
			end
			clean_lines = truncated
		end
		data["log"] = table.concat(clean_lines, "\n")
	end

	if not data["log"] or data["log"] == "" then
		if data["state"] == "Downloading" then
			data["log"] = string.format("[1/3] Download pacchetto GUI in corso... (%d%%)", math.floor(data["progress"] or 0))
		elseif data["state"] == "Extracting" then
			data["log"] = "[1/3] Download pacchetto completato.\n[2/3] Estrazione e installazione componenti in corso..."
		elseif data["state"] == "In Progress" then
			data["log"] = "[1/3] Download pacchetto completato.\n[2/3] Estrazione completata.\n[3/3] Finalizzazione script di sistema e riavvio servizi..."
		elseif data["state"] == "Requested" then
			data["log"] = "[Inizializzazione] Avvio procedura in corso..."
		elseif data["state"] == "Complete" then
			data["log"] = "[Aggiornamento] Operazione completata con successo!"
		elseif data["state"] == "Failed" or data["state"] == "Error" then
			data["log"] = "[Errore] Operazione terminata con errore. Controllare i log di sistema."
		end
	end
end



local buffer = {}
if json.encode (data, { indent = false, buffer = buffer }) then
	ngx.say(buffer)
else
	ngx.say("{}")
end

ngx.exit(ngx.HTTP_OK)
