--pretranslated: do not change this file

-- Enable localization
gettext.textdomain('webui-core')

local proxy = require("datamodel")
local ui_helper = require("web.ui_helper")
local content_helper = require("web.content_helper")
local format,sub,match = string.format, string.sub, string.match

local app_list = {
	"luci",
	"aria2",
	"transmission",
	"adblock",
	"rsyncd",
	"speedtest",
	"adguardhome",
	"openspeedtest",
	"wireguard",
	"l2tpipsec",
	"openvpn",
	"tailscale",
	"smartphone",
	"dumaos",
	"amule",
	"voipblockmmpbx",
	"voipblockasterisk",
	"blacklist",
	"xupnp",
	"telstra",
}

local marketing_version = proxy.get("uci.version.version.@version[0].marketing_version")
local cputype_res = proxy.get("rpc.system.modgui.CPUtype")
local cputype = (cputype_res and cputype_res[1] and cputype_res[1].value) or ""
local specific_app_res = proxy.get("uci.modgui.app.specific_app")
local specific_app = (specific_app_res and specific_app_res[1] and specific_app_res[1].value) or "0"
local mv = 0
if marketing_version and marketing_version[1] and marketing_version[1].value then
	mv = tonumber(marketing_version[1].value:sub(1,4)) or 0
end
marketing_version = mv

local function appapply(action)
	proxy.set("rpc.system.modgui.app.sendcmd", action)
	proxy.apply()
	ngx.header.content_type = "application/json"
	ngx.print('{ "success":"true" }')
	ngx.exit(ngx.HTTP_OK)
end

if ngx.req.get_method() == "POST" then
	local post_args = ngx.req.get_post_args()
	local raw_action = post_args and post_args.action
	local action = raw_action and string.untaint(raw_action)
	if action and (action:match("^install_") or action:match("^remove_") or action:match("^start_") or action:match("^stop_") or action:match("^restart_")) then
		return appapply(action)
	end
end

-- Use the hostname of the page request, including access through other interfaces.
local webui_host = ngx.var.host or "192.168.1.1"
if webui_host:find(":", 1, true) and webui_host:sub(1, 1) ~= "[" then
	webui_host = "[" .. webui_host .. "]"
end

local mapParams = {
    smartphone_application = "uci.modgui.app.smartphone_app",
	telstra_webui = "uci.modgui.app.telstra_webui",
	xupnp_application = "uci.modgui.app.xupnp_app",
}
if marketing_version >= 16.3 then
	mapParams.luci_webui = "uci.modgui.app.luci_webui"
end
mapParams.aria2_webui = "uci.modgui.app.aria2_webui"
mapParams.transmission_webui = "uci.modgui.app.transmission_webui"
mapParams.adblock_application = "uci.modgui.app.adblock_app"
mapParams.rsyncd_application = "uci.modgui.app.rsyncd_app"
mapParams.openspeedtest_application = "uci.modgui.app.openspeedtest_app"
if cputype:match("^mips") or cputype:match("^armv7") then
	mapParams.amule_webui = "uci.modgui.app.amule_webui"
end
if cputype:match("^armv7") or cputype:match("^mips") then
	mapParams.l2tpipsec_application = "uci.modgui.app.l2tpipsec_app"
end
if cputype:match("^armv7") or cputype:match("^mips") then
	mapParams.openvpn_application = "uci.modgui.app.openvpn_app"
end
if cputype:match("^armv7") or cputype == "aarch64" or cputype == "arm64" then
	mapParams.speedtest_application = "uci.modgui.app.speedtest_app"
	mapParams.adguardhome_application = "uci.modgui.app.adguardhome_app"
	mapParams.tailscale_application = "uci.modgui.app.tailscale_app"
end
if cputype:match("^armv7") or cputype == "aarch64" or cputype == "arm64" or cputype == "mips" then
	mapParams.wireguard_application = "uci.modgui.app.wireguard_app"
end
if cputype:match("^armv7") then
	mapParams.dumaos_application = "uci.modgui.app.dumaos_app"
end
content_helper.getExactContent(mapParams)

local StateParams = {}

for Params in pairs(mapParams) do
	if mapParams[Params] and mapParams[Params] == "1" then
		StateParams[Params] = ""
	else
		StateParams[Params] = T"not"
	end
end

ngx.print('\
\
');  ngx.print(ui_helper.createHeader(T"Application List", false, false))   ngx.print('\
<div class="modal-body update applications-modal-body">\
<fieldset class="applications-list-shell">\
    <form class="form-horizontal applications-list-form" method="post" action="/modals/applications-modal.lp">\
    ');
local info_box = {
	alert = {
		class = "alert alert-info",
	}
}
local specific_box = {
	alert = {
		class = "alert-error"
	}
}
local notices = {}
local html = {}

if specific_app == "0" then
	notices[#notices + 1] = ui_helper.createAlertBlock(T"Specific App are not installed. This can cause errors for app setup. Go to Mod GUI modal to install",specific_box)
end
notices[#notices + 1] = ui_helper.createAlertBlock(T"Make sure the gateway have an active internet connection to allow app download and installation",info_box)
local btn_table = {}

for _, app in ipairs(app_list) do
	btn_table[app] = {}
	for _, action in ipairs({"install","remove","start","stop"}) do
		btn_table[app][action] =
		{
			button = {
				id = "btn-"..action.."_"..app
			}
		}
	end
end

local function escape_html(value)
	return (value or ""):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"):gsub('"', "&quot;"):gsub("'", "&#39;")
end

-- Read the filesystem used by the installers, not the inactive firmware bank.
local has_posix, posix = pcall(require, "tch.posix")
local function free_space(path)
	if has_posix then
		local ok, stat = pcall(posix.statvfs, path)
		if ok and type(stat) == "table" then
			local blocks = tonumber(stat.f_bavail)
			local size = tonumber(stat.f_frsize) or tonumber(stat.f_bsize)
			if blocks and size and blocks >= 0 and size > 0 then
				local mib = blocks * size / 1048576
				return mib >= 1024 and format("%.2f GiB", mib / 1024) or format("%.2f MiB", mib)
			end
		end
	end
	return T"Unavailable"
end

local storage = {
	'<div class="applications-storage" role="status"><strong>' .. T"Available space" .. '</strong>',
	'<span>' .. T"Internal storage" .. ': ' .. free_space("/usr") .. '</span>',
}
local mounts = io.open("/proc/mounts", "r")
local usb_found = false
if mounts then
	for line in mounts:lines() do
		local device, mount, options = line:match("^(%S+)%s+(%S+)%s+%S+%s+(%S+)")
		if device and device:match("^/dev/sd[a-z]%d*$") and mount:match("^/tmp/run/mountd/sd[a-z]%d*$") then
			usb_found = true
			local readonly = not ("," .. options .. ","):find(",rw,", 1, true)
			storage[#storage+1] = '<span>USB ' .. escape_html(device:match("[^/]+$")) .. ': ' .. free_space(mount) ..
				(readonly and (' (' .. T"Read-only" .. ')') or '') .. '</span>'
		end
	end
	mounts:close()
end
if not usb_found then
	storage[#storage+1] = '<span>' .. T"USB: no mounted drive" .. '</span>'
end
storage[#storage+1] = '</div>'
notices[#notices+1] = table.concat(storage)

local usb_required = {
	amule_webui = true,
	aria2_webui = true,
	transmission_webui = true,
}

local function append_app_status(state_key, title)
	if usb_required[state_key] then
		html[#html+1] = '<p class="application-usb-required"><span class="application-usb-badge">' .. T"USB required" .. '</span> ' ..
			T"A writable USB drive and free internal storage are required." .. '</p>'
	end
	html[#html+1] = '<div class="application-card-status">'
	html[#html+1] = ui_helper.createSimpleLight(
		mapParams[state_key] == "1" and "1" or "0",
		title,
		{ span = { class = "simple-desc application-status" } }
	)
	html[#html+1] = "</div>"
end

local function append_extension_card(state_key, app, title, description, link, can_run, result)
	html[#html+1] = '<div class="application-card">'
	html[#html+1] = "<fieldset>"
	html[#html+1] = '<legend>' .. title .. '</legend>'
	html[#html+1] = ui_helper.createAlertBlock(description, info_box)
	append_app_status(state_key, title)
	if link then
		html[#html+1] = T"Webui on: " .. '<a target="_blank" href="' .. link .. '">' .. link .. "</a><br/>"
	end
	if result and result ~= "" then
		html[#html+1] = '<pre style="white-space:pre-wrap;max-height:12rem;overflow:auto;">' .. escape_html(result) .. '</pre>'
	end
	html[#html+1] = "<br/>"
	if mapParams[state_key] == "1" then
		if can_run then
			html[#html+1] = ui_helper.createSimpleButton(T"Start" .. " " .. title, "fa fa-play", btn_table[app].start)
			html[#html+1] = ui_helper.createSimpleButton(T"Stop" .. " " .. title, "fa fa-stop", btn_table[app].stop)
		end
		html[#html+1] = ui_helper.createSimpleButton(T"Remove" .. " " .. title, "fa fa-times-circle", btn_table[app].remove)
	else
		html[#html+1] = ui_helper.createSimpleButton(T"Install" .. " " .. title, "fa fa-download", btn_table[app].install)
	end
	html[#html+1] = "</fieldset>"
	html[#html+1] = "</div>"
end

local function native_wireguard_supported()
    local result = proxy.get("rpc.system.modgui.WireGuardSupported")
    return result and result[1] and result[1].value == "1"
end

local function tun_install_supported()
    local result = proxy.get("rpc.system.modgui.TunSupported")
    return result and result[1] and result[1].value == "1"
end

if StateParams["luci_webui"] ~= nil then
	html[#html+1] = '<div class="application-card">'
	html[#html+1] = "<fieldset>"
	html[#html+1] = '<legend>' .. T"LuCI GUI" .. '</legend>'
	html[#html+1] = ui_helper.createAlertBlock(T"This will install uHTTPd and LuCI", info_box)
	append_app_status("luci_webui", T"LuCI GUI")
	local luci_link = format("http://%s:9080", webui_host)
	html[#html+1] = T"Webui on: " .. '<a target="_blank" href="' .. luci_link .. '">' .. luci_link .. "</a>"
	html[#html+1] = "<br/>"
	html[#html+1] = "<br/>"
	if mapParams["luci_webui"] and mapParams["luci_webui"] == "1" then
		html[#html+1] = ui_helper.createSimpleButton(T"Remove".." LuCI", "fa fa-times-circle", btn_table.luci.remove)
	else
		html[#html+1] = ui_helper.createSimpleButton(T"Install".." LuCI", "fa fa-download", btn_table.luci.install)
	end
	html[#html+1] = "<br/>"
	html[#html+1] = "</fieldset>"
	html[#html+1] = "</div>"
end

if StateParams["amule_webui"] ~= nil then
	html[#html+1] = '<div class="application-card">'
	html[#html+1] = "<fieldset>"
	html[#html+1] = '<legend>' .. T"aMule" .. '</legend>'
	html[#html+1] = ui_helper.createAlertBlock(T"This will install aMule webui", info_box)
	append_app_status("amule_webui", T"aMule")
	local amule_direct_link = format("http://%s:4711/", webui_host)
	html[#html+1] = T"Webui on: " .. '<a target="_blank" href="' .. amule_direct_link .. '">' .. amule_direct_link .. "</a>"
	html[#html+1] = "<br/>"
	if mapParams["amule_webui"] and mapParams["amule_webui"] == "1" then
		local password_file = io.open("/etc/modgui-amule-web.password", "r")
		if password_file then
			local password = (password_file:read(256) or ""):gsub("[\r\n]+$", "")
			password_file:close()
			if password ~= "" then
				html[#html+1] = '<label for="amule-web-password">' .. T"WebUI password" .. '</label>'
				html[#html+1] = '<input id="amule-web-password" class="input-block-level" type="password" readonly autocomplete="off" value="' .. escape_html(password) .. '">'
				html[#html+1] = '<label class="checkbox" for="amule-show-password"><input id="amule-show-password" type="checkbox" aria-controls="amule-web-password">' .. T"Show password" .. '</label>'
			end
		end
		html[#html+1] = ui_helper.createSimpleButton(T"Start".." aMule", "fa fa-play", btn_table.amule.start)
		html[#html+1] = ui_helper.createSimpleButton(T"Stop".." aMule", "fa fa-stop", btn_table.amule.stop)
		html[#html+1] = ui_helper.createSimpleButton(T"Remove".." aMule", "fa fa-times-circle", btn_table.amule.remove)
	else
		html[#html+1] = ui_helper.createSimpleButton(T"Install".." aMule", "fa fa-download", btn_table.amule.install)
	end
	html[#html+1] = "</fieldset>"
	html[#html+1] = "</div>"
end
if StateParams["aria2_webui"] ~= nil then
	html[#html+1] = '<div class="application-card">'
	html[#html+1] = "<fieldset>"
	html[#html+1] = '<legend>' .. T"Aria2 GUI" .. '</legend>'
	html[#html+1] = ui_helper.createAlertBlock(T"This will install aria2 and ariang webui", info_box)
	append_app_status("aria2_webui", T"Aria2 GUI")
	local aria_link =  '/aria'
	html[#html+1] = T"Webui on: " .. '<a target="_blank" href="' .. aria_link .. '">' .. aria_link .."</a>"
	html[#html+1] = "<br/>"
	html[#html+1] = "<br/>"
	if mapParams["aria2_webui"] and mapParams["aria2_webui"] == "1" then
        if cputype:match("mips") then
            html[#html+1] = ui_helper.createSimpleButton(T"Start".." Aria2", "fa fa-play", btn_table.aria2.start)
            html[#html+1] = ui_helper.createSimpleButton(T"Stop".." Aria2", "fa fa-stop", btn_table.aria2.stop)
        end
		html[#html+1] = ui_helper.createSimpleButton(T"Remove".." Aria2", "fa fa-times-circle", btn_table.aria2.remove)
	else
		html[#html+1] = ui_helper.createSimpleButton(T"Install".." Aria2", "fa fa-download", btn_table.aria2.install)
	end
	html[#html+1] = "</fieldset>"
	html[#html+1] = "</div>"
end

if StateParams["transmission_webui"] ~= nil then
	html[#html+1] = '<div class="application-card">'
	html[#html+1] = "<fieldset>"
	html[#html+1] = '<legend>' .. T"Transmission GUI" .. '</legend>'
	html[#html+1] = ui_helper.createAlertBlock(T"This will install transmission and transmission-webui", info_box)
	append_app_status("transmission_webui", T"Transmission GUI")
	local transmission_direct_link = format("http://%s:9091/transmission", webui_host)
	html[#html+1] = T"Webui on: " .. '<a target="_blank" href="' .. transmission_direct_link .. '">' .. transmission_direct_link .. "</a>"
	html[#html+1] = "<br/>"
	html[#html+1] = "<br/>"
	if mapParams["transmission_webui"] and mapParams["transmission_webui"] == "1" then
        if cputype:match("mips") then
            html[#html+1] = ui_helper.createSimpleButton(T"Start".." Tansmission", "fa fa-play", btn_table.transmission.start)
            html[#html+1] = ui_helper.createSimpleButton(T"Stop".." Transmission", "fa fa-stop", btn_table.transmission.stop)
        end
		html[#html+1] = ui_helper.createSimpleButton(T"Remove".." Transmission", "fa fa-times-circle", btn_table.transmission.remove)
	else
		html[#html+1] = ui_helper.createSimpleButton(T"Install".." Transmission", "fa fa-download", btn_table.transmission.install)
	end
	html[#html+1] = "</fieldset>"
	html[#html+1] = "</div>"
end

if StateParams["adblock_application"] ~= nil then
	append_extension_card(
		"adblock_application",
		"adblock",
		T"Adblock",
		T"Blocks advertising domains at router level. Requires working opkg feeds.",
		nil,
		true
	)
end

if StateParams["rsyncd_application"] ~= nil then
	append_extension_card(
		"rsyncd_application",
		"rsyncd",
		T"Rsync daemon",
		T"Installs the rsync daemon. Configure authenticated shares before starting the service.",
		nil,
		true
	)
end

if StateParams["speedtest_application"] ~= nil then
	local speedtest_result = ""
	local speedtest_file = io.open("/tmp/speedtest-result.txt", "r")
	if speedtest_file then
		speedtest_result = speedtest_file:read("*all") or ""
		speedtest_file:close()
		-- Keep only the latest version of lines rewritten by CLI progress.
		speedtest_result = speedtest_result:gsub("\r\n", "\n"):gsub("[^\r\n]*\r", "")
		if #speedtest_result > 4096 then
			speedtest_result = speedtest_result:sub(-4096)
		end
	end
	append_extension_card(
		"speedtest_application",
		"speedtest",
		T"Ookla Speedtest",
		T"Runs an internet speed test on this ARM gateway. Select Start to view live progress and results in the terminal window.",
		nil,
		true,
		speedtest_result
	)
end

if StateParams["adguardhome_application"] ~= nil then
	local adguard_port = "3000"
	local adguard_config = io.open("/opt/AdGuardHome/AdGuardHome.yaml", "r")
	if adguard_config then
		local in_http = false
		for line in adguard_config:lines() do
			if line:match("^http:%s*$") then
				in_http = true
			elseif line:match("^%S") then
				in_http = false
			elseif in_http then
				local configured_port = line:match("address:%s*.*:(%d+)%s*$")
				if configured_port then
					adguard_port = configured_port
					break
				end
			end
		end
		adguard_config:close()
	end
	local adguard_link = format("http://%s:%s", webui_host, adguard_port)
	append_extension_card(
		"adguardhome_application",
		"adguardhome",
		T"AdGuard Home",
		T"Installs AdGuard Home without changing dnsmasq or port 53. Complete the safe first-run setup in its web interface.",
		adguard_link,
		true
	)
end

if StateParams["openspeedtest_application"] ~= nil then
	local openspeedtest_link = format("http://%s:5678", webui_host)
	append_extension_card(
		"openspeedtest_application",
		"openspeedtest",
		T"OpenSpeedTest",
		T"Runs a browser-based LAN and Wi-Fi speed test directly against this gateway without using internet traffic.",
		openspeedtest_link,
		true
	)
end

if StateParams["wireguard_application"] ~= nil then
	if native_wireguard_supported() or tun_install_supported() then
		append_extension_card(
			"wireguard_application",
			"wireguard",
			T"WireGuard",
			T"Installs native WireGuard matching the running kernel from the configured package feeds, or the userspace runtime when unavailable, and a card to configure the tunnel interface, peers and firewall rules. Everything stays disabled until configured.",
			nil,
			false
		)
	else
		html[#html+1] = '<div class="application-card">'
		html[#html+1] = "<fieldset>"
		html[#html+1] = '<legend>' .. T"WireGuard" .. '</legend>'
		html[#html+1] = ui_helper.createAlertBlock(T"Unavailable: no reviewed TUN module is available for this firmware.", specific_box)
		html[#html+1] = "</fieldset>"
		html[#html+1] = "</div>"
	end
end

if StateParams["l2tpipsec_application"] ~= nil then
	append_extension_card(
		"l2tpipsec_application",
		"l2tpipsec",
		T"L2TP/IPsec VPN",
		T"Installs the legacy strongSwan and xl2tpd VPN server card. The server stays disabled after installation; prefer IKEv2 or WireGuard for new deployments.",
		nil,
		true
	)
end

if StateParams["openvpn_application"] ~= nil then
	if tun_install_supported() then
		append_extension_card(
			"openvpn_application",
			"openvpn",
			T"OpenVPN",
			T"Installs OpenVPN server and client management. Both modes and the server WAN rule remain disabled until explicitly enabled.",
			nil,
			true
		)
	else
		html[#html+1] = '<div class="application-card">'
		html[#html+1] = "<fieldset><legend>" .. T"OpenVPN" .. "</legend>"
		html[#html+1] = ui_helper.createAlertBlock(T"Unavailable: no reviewed TUN module is available for this firmware.", specific_box)
		html[#html+1] = "</fieldset></div>"
	end
end

if StateParams["smartphone_application"] ~= nil then
    append_extension_card(
        "smartphone_application", "smartphone", T"Smartphone USB",
        T"Installs Android telemetry and USB tethering controls as an optional app, with ADB from the configured opkg feeds. Android USB debugging authorization is required; VPN sharing also requires Android root.",
        nil, false
    )
end

if StateParams["tailscale_application"] ~= nil then
	if tun_install_supported() then
		append_extension_card(
			"tailscale_application",
			"tailscale",
			T"Tailscale",
			T"Installs a pinned official Tailscale runtime and a management card. The daemon, routes, exit-node mode and firewall access remain disabled until configured.",
			nil,
			false
		)
	else
		html[#html+1] = '<div class="application-card">'
		html[#html+1] = "<fieldset><legend>" .. T"Tailscale" .. "</legend>"
		html[#html+1] = ui_helper.createAlertBlock(T"Unavailable: no reviewed TUN module is available for this firmware.", specific_box)
		html[#html+1] = "</fieldset></div>"
	end
end

if StateParams["dumaos_application"] ~= nil then
	local check = io.popen("/usr/share/transformer/scripts/appInstallRemoveUtility.sh check dumaos; echo $?", "r")
	local supported = check and check:read("*line") == "0"
	if check then check:close() end
	if supported or mapParams.dumaos_application == "1" then
	local dumaos_link = "/desktop/"
	append_extension_card(
		"dumaos_application",
		"dumaos",
		T"DumaOS",
		T"Installs the pinned DumaOS UI and QoS stack for supported ARMv7 Technicolor gateways. The required ubus ABI is activated transactionally with a verified stock backup and automatic rollback.",
		dumaos_link,
		true
	)
	else
		html[#html+1] = '<div class="application-card"><fieldset><legend>' .. T"DumaOS" .. '</legend>'
		html[#html+1] = ui_helper.createAlertBlock(T"Unavailable: DumaOS requires a supported ARMv7 gateway with kernel 4.1.52.", specific_box)
		html[#html+1] = '</fieldset></div>'
	end
end

if StateParams["voipblock_for_mmpbx"] ~= nil then
	html[#html+1] = '<div class="application-card">'
	html[#html+1] = "<fieldset>"
	html[#html+1] = '<legend>' .. T"Voipblock for mmpbx" .. '</legend>'
	html[#html+1] = ui_helper.createAlertBlock(T"This will install Voipblock for mmpbx", info_box)
	append_app_status("voipblock_for_mmpbx", T"Voipblock for mmpbx")
	html[#html+1] = "<br/>"
	html[#html+1] = "<br/>"
	if mapParams["voipblock_for_mmpbx"] and mapParams["voipblock_for_mmpbx"] == "1" then
		html[#html+1] = ui_helper.createSimpleButton(T"Remove".." Voipblock for mmpbx", "fa fa-times-circle", btn_table.voipblockmmpbx.remove)
	else
		html[#html+1] = ui_helper.createSimpleButton(T"Install".." Voipblock for mmpbx", "fa fa-download", btn_table.voipblockmmpbx.install)
	end
	html[#html+1] = "</fieldset>"
	html[#html+1] = "<br/>"
	html[#html+1] = "</div>"
end

if StateParams["voipblock_for_asterisk"] ~= nil then
	html[#html+1] = '<div class="application-card">'
	html[#html+1] = "<fieldset>"
	html[#html+1] = '<legend>' .. T"Voipblock for asterisk" .. '</legend>'
	html[#html+1] = ui_helper.createAlertBlock(T"This will install Voipblock for asterisk", info_box)
	append_app_status("voipblock_for_asterisk", T"Voipblock for asterisk")
	html[#html+1] = "<br/>"
	html[#html+1] = "<br/>"
	if mapParams["voipblock_for_asterisk"] and mapParams["voipblock_for_asterisk"] == "1" then
		html[#html+1] = ui_helper.createSimpleButton(T"Remove".." Voipblock for asterisk", "fa fa-times-circle", btn_table.voipblockasterisk.remove)
	else
		html[#html+1] = ui_helper.createSimpleButton(T"Install".." Voipblock for asterisk", "fa fa-download", btn_table.voipblockasterisk.install)
	end
	html[#html+1] = "</fieldset>"
	html[#html+1] = "<br/>"
	html[#html+1] = "</div>"
end

if StateParams["blacklist_application"] ~= nil then
	btn_table.blacklist.installempty = {
		button = {
			id = "btn-install_blacklist_empty"
		}
	}
	html[#html+1] = '<div class="application-card">'
	html[#html+1] = "<fieldset>"
	html[#html+1] = '<legend>' .. T"Blacklist App" .. '</legend>'
	html[#html+1] = ui_helper.createAlertBlock(T"This will install the blacklist application", info_box)
	append_app_status("blacklist_application", T"Blacklist App")
	local blacklist_link = "http://blacklist.satellitar.it/"
	html[#html+1] = T"Support site: " .. '<a  target="_blank" href="' .. blacklist_link .. '">' .. blacklist_link .."</a>"
	html[#html+1] = "<br/>"
	html[#html+1] = "<br/>"
	local empty_blacklist_msg = ""
	if mapParams["blacklist_application"] and mapParams["blacklist_application"] == "1" then
		html[#html+1] = ui_helper.createSimpleButton(T"Remove".." Blacklist", "fa fa-times-circle", btn_table.blacklist.remove)
		empty_blacklist_msg = T"Update blacklist app"
	else
		html[#html+1] = ui_helper.createSimpleButton(T"Install".." Blacklist", "fa fa-download", btn_table.blacklist.install)
		empty_blacklist_msg = T"Install empty blacklist"
	end
	html[#html+1] = ui_helper.createSimpleButton(empty_blacklist_msg, "fa fa-download", btn_table.blacklist.installempty)

	html[#html+1] = "</fieldset>"
	html[#html+1] = "</div>"
end

if StateParams["xupnp_application"] ~= nil then
	html[#html+1] = '<div class="application-card">'
	html[#html+1] = "<fieldset>"
	html[#html+1] = '<legend>' .. T"XUPnP App" .. '</legend>'
	html[#html+1] = ui_helper.createAlertBlock(T"This will install the XUPnP application", info_box)
	append_app_status("xupnp_application", T"XUPnP App")
	local xupnp_link = format("http://%s:4044/ui/", webui_host)
	html[#html+1] = T"Webui on: " .. '<a target="_blank" href="' .. xupnp_link .. '">' .. xupnp_link .."</a>"
	html[#html+1] = "<br/>"
	html[#html+1] = "<br/>"
	if mapParams["xupnp_application"] and mapParams["xupnp_application"] == "1" then
		html[#html+1] = ui_helper.createSimpleButton(T"Remove".." XUPnP", "fa fa-times-circle", btn_table.xupnp.remove)
	else
		html[#html+1] = ui_helper.createSimpleButton(T"Install".." XUPnP", "fa fa-download", btn_table.xupnp.install)
	end
	html[#html+1] = "</fieldset>"
	html[#html+1] = "<br/>"
	html[#html+1] = "</div>"
end

if StateParams["telstra_webui"] ~= nil then
	html[#html+1] = '<div class="application-card">'
	html[#html+1] = "<fieldset>"
	html[#html+1] = '<legend>' .. T"Telstra GUI" .. '</legend>'
	html[#html+1] = ui_helper.createAlertBlock(T"This will install Telstra webui", info_box)
	append_app_status("telstra_webui", T"Telstra GUI")
	local telstra_gui = "/telstra-gui.lp"
	html[#html+1] = T"Webui on: " .. '<a target="_blank" href="' .. telstra_gui .. '">' .. telstra_gui .."</a>"
	html[#html+1] = "<br/>"
	html[#html + 1] = T "Change the default page in system-extra to set this GUI as default"
	html[#html+1] = "<br/>"
	if mapParams["telstra_webui"] and mapParams["telstra_webui"] == "1" then
		html[#html+1] = ui_helper.createSimpleButton(T"Remove" .. " " .. T"Telstra GUI", "fa fa-times-circle", btn_table.telstra.remove)
	else
		html[#html+1] = ui_helper.createSimpleButton(T"Install" .. " " .. T"Telstra GUI", "fa fa-download", btn_table.telstra.install)
	end
	html[#html+1] = "</fieldset>"
	html[#html+1] = "</div>"
end
ngx.print(notices)
ngx.print('<div class="applications-grid">')
ngx.print(html)
ngx.print('</div>')
ngx.print('\
    </form>\
  </fieldset>\
</div>\
\
<script>\
(function() {\
    $("#amule-show-password").on("change", function() {\
      $("#amule-web-password").attr("type", this.checked ? "text" : "password");\
    });\
    $("div[id^=\'btn-\']").on("click", function() {\
      var btnact = $(this).attr("id").replace("btn-", "");\
      var showLog = (btnact.indexOf("install") === 0 || btnact.indexOf("remove") === 0) ? 1 : 0;\
      modgui.postAction(btnact, showLog);\
    });\
}());\
</script>\
');
ngx.print(ui_helper.createFooter())
