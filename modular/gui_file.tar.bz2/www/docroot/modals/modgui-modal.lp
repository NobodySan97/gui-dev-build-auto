--pretranslated: do not change this file

-- Enable localization
gettext.textdomain('webui-core')

local lp = require("web.lp")
local proxy = require("datamodel")
local ui_helper = require("web.ui_helper")
local message_helper = require("web.uimessage_helper")
local content_helper = require("web.content_helper")
local post_helper = require("web.post_helper")
local https_support = {}
do
    -- Check local prerequisites without opening ports or changing firewall policy.
    local uci = require("uci")
    local M = https_support
    local function plain(value)
        return type(value) == "string" and string.untaint and string.untaint(value) or value
    end
    local function contains(value, wanted)
        if type(value) == "table" then
            for _, item in ipairs(value) do if contains(item, wanted) then return true end end
        elseif type(value) == "string" then
            for item in plain(value):gmatch("%S+") do
                if item == wanted or item == "all" or item == "*" then return true end
                local first, last = item:match("^(%d+)[%-:](%d+)$")
                if first and tonumber(wanted) and tonumber(first) <= tonumber(wanted)
                    and tonumber(last) >= tonumber(wanted) then return true end
            end
        end
        return false
    end
    local function listening(path)
        local file = io.open(path, "r")
        if not file then return false end
        local found = false
        for line in file:lines() do
            local address, port, state = line:match("^%s*%d+:%s+(%x+):(%x+)%s+%x+:%x+%s+(%x+)")
            if port == "01BB" and state == "0A" and address ~= "0100007F"
                and address ~= "00000000000000000000000001000000" then found = true end
        end
        file:close()
        return found
    end
    function M.available()
        if not listening("/proc/net/tcp") and not listening("/proc/net/tcp6") then
            return false, "HTTPS is unavailable: no local listener on port 443."
        end
        local cursor = uci.cursor()
        local blocked = false
        local ok, result = pcall(function()
            return cursor:foreach("firewall", "rule", function(rule)
                -- Only unconditional LAN input blocks: forwarded traffic and
                -- restrictions for individual hosts must not disable the setting.
                if plain(rule.src) == "lan" and not rule.dest and rule.enabled ~= "0"
                    and (rule.target == "DROP" or rule.target == "REJECT")
                    and (not rule.proto or contains(rule.proto, "tcp"))
                    and (not rule.dest_port or contains(rule.dest_port, "443"))
                    and not rule.src_ip and not rule.dest_ip and not rule.src_mac
                    and not rule.src_port and not rule.extra and not rule.ipset
                    and not rule.start_time and not rule.stop_time
                    and not rule.start_date and not rule.stop_date
                    and not rule.weekdays and not rule.monthdays then blocked = true end
            end)
        end)
        cursor:unload("firewall")
        if not ok or result ~= true then
            return false, "HTTPS availability could not be verified."
        end
        if blocked then return false, "HTTPS is blocked by a LAN firewall rule on port 443." end
        return true
    end
    function M.validate(value)
        if value ~= "0" and value ~= "1" then return nil, "Invalid value" end
        if value == "0" then return true end
        local available, reason = M.available()
        if not available then return nil, reason end
        return true
    end
end
local https_available, https_reason = https_support.available()
local format,find,sub, match, untaint = string.format, string.find, string.sub, string.match, string.untaint
local vB = post_helper.validateBoolean
local gOrV = post_helper.getOrValidation
local gAV = post_helper.getAndValidation
local gOV = post_helper.getOptionalValidation

local function wait_for_completion(base_path)
  local state_path = base_path .. "state"
  local sleep_time = 0.250
  local max_time = 7
  local total_time = 0
  local content
  repeat
    ngx.sleep(sleep_time)
    total_time = total_time + sleep_time

    content = { state = state_path }
    content_helper.getExactContent(content)

    if content.state == "Complete" or content.state == "Error" or content.state == "Failed" then
      break
    end
  until (total_time >= max_time)
end

local function receive_file(filename, match)
        function do_receive(outfile, match)
                local upload = require("web.fileupload")
                local form, err = upload.fromstream()
                if not form then
                        return false, 1, "failed to create upload ctx: " .. err
                end
                local totalsize = 0
                local file
                local discard = false
                while true do
                        local token, data, err = form:read()
                        if not token then
                                return false, 2, "read failed: " .. err
                        end
                        if token == "header" then
                                if not discard and not file and find(data[2], match, 1, true) then
                                        file = outfile
                                end
                                if not discard and not file then
                                        return false, 3, "failed to start receiving file"
                                end
                        elseif token == "body" then
                                if file then
                                        totalsize = totalsize + #data
                                        file:write(data)
                                end
                        elseif token == "part_end" then
                                if file then
                                        file = nil
                                        discard = true
                                end
                        elseif token == "eof" then
                                break
                        end
                end
                return true
        end

        local file = io.open(filename, "w")
        local result, err_code, err_msg
        if file then
                result, err_code, err_msg = do_receive(file, match)
        else
                file = io.open("/dev/null", "w")
                do_receive(file, match)
                result = false
                err_code = 4
                err_msg = "internal error"
        end

        file:close()

        return result, err_code, err_msg
end

local function sendcmd(cmd)
        os.remove("/tmp/command_log")
        proxy.set("rpc.system.modgui.executeCommand.state", "Requested")
        proxy.set("rpc.system.modgui.utility.sendcmd", cmd)
        proxy.apply()
        ngx.print('{"success":"true"}')
        ngx.exit(ngx.HTTP_OK)
end

local function upgradeguifile()

        local update_branch = proxy.get("uci.modgui.gui.update_branch")
        local filename
        if update_branch and update_branch[1].value ~= "stable" and update_branch[1].value ~= "" then
                filename = "GUI_"..untaint(update_branch[1].value)..".tar.bz2"
        else
                filename = "GUI.tar.bz2"
        end

        local fwupgrade_location = "/tmp/"

        -- flush the web template cache
        lp.flush()
        local dl = untaint(fwupgrade_location) .. filename
        local rcv_ok, rcv_errno, rcv_errmsg = receive_file(dl, 'name="upgradefile"')
        if rcv_ok then
                ngx.print('{"success":"true"}')
                ngx.exit(ngx.HTTP_OK)
        else
                ngx.print('{"error":"'..rcv_errmsg..'"}')
                ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
        end
end

local function getSupportedModel()

        local _fn = proxy.get("uci.env.var.prod_friendly_name"); local friendly_name = (_fn and _fn[1] and _fn[1].value) or ""
        local marketing_version = proxy.get("uci.version.version.@version[0].marketing_version")
        local _ct = proxy.get("rpc.system.modgui.CPUtype"); local cputype = (_ct and _ct[1] and _ct[1].value) or ""
        if marketing_version then
                marketing_version = tonumber(marketing_version[1].value:sub(1,4))
        end

        if marketing_version < 16.3 then
                if cputype:match("armv7l") then
                        return "TG789Xtream35B"
                elseif cputype:match("mips") then
                        return "TG789"
                end
        elseif marketing_version < 18 then
                if cputype:match("armv7l") then
                        if friendly_name:match("TG800") then
                                return "TG800"
                        else
                                return "DGA"
                        end
                elseif cputype:match("mips") then
                        return "TG789"
                end
        else
                if cputype:match("armv7l") then
                        return "DGA"
                elseif cputype:match("mips") then
                        return friendly_name --Unknown package
                end
        end

        return friendly_name --Unknown package
end

local function installspecificapp()

        local device = getSupportedModel()

        local fwupgrade_location = "/tmp/"

        -- flush the web template cache
        lp.flush()

        local dl = untaint(fwupgrade_location) .. "upgrade-pack-specific" .. device .. ".tar.bz2"

        local rcv_ok, rcv_errno, rcv_errmsg = receive_file(dl, 'name="specificapp_file"')

        if rcv_ok then
                ngx.print('{"success":"true"}')
                ngx.exit(ngx.HTTP_OK)
        else
                ngx.print('{"error":"'..rcv_errmsg..'"}')
                ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
        end
end

local function restoreFromSysupgradeBackup()

        local dl = "/tmp/sysupgrade_backup.tar.gz"

        -- flush the web template cache
        lp.flush()

        local rcv_ok, rcv_errno, rcv_errmsg = receive_file(dl, 'name="sysupgrade_backup"')

        if rcv_ok then
                sendcmd("restoreSysupgradeBackup")
        else
                ngx.print('{"error":"'..rcv_errmsg..'"}')
                ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
        end
end

local function genSysupgradeBackup()

        local hostname = proxy.get("uci.system.system.@system[0].hostname")
        hostname = hostname and hostname[1].value or "Unknown"
        local filename = format("%s-%s.tar.gz",hostname,os.date("%d-%m-%y_%H:%m"))

        proxy.set("rpc.system.modgui.utility.sendcmd", "genSysupgradeBackup_"..filename)
        wait_for_completion("rpc.system.modgui.executeCommand.")

    -- return exported data
        if filename ~= "" then
                ngx.header.content_disposition = "attachment; filename="..filename
                ngx.header.content_type = "application/octet-stream"
                ngx.header.set_cookie = "fileDownload=true; Path=/"  -- the JS download code requires this cookie
                local f = io.open("/tmp/"..filename, "r")
                if f then
                        ngx.print(f:read("*all"))
                        f:close()
                        os.remove("/tmp/"..filename)

                        -- and we're done
                        ngx.exit(ngx.HTTP_OK)
                end
        end

        ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
end

local function call_popen(cmd)

        local handle = io.popen(cmd)
        local result = handle:read("*a")
        handle:close()

        return result
end

if ngx.req.get_method() == "POST" then
        -- now process file POSTs
        local action = ngx.req.get_uri_args().action
        if action == "upgradeguifile" then
                return upgradeguifile()
        end
        if action == "installspecificapp" then
                return installspecificapp()
        end
        if action == "system_restoreBackup" then
                return restoreFromSysupgradeBackup()
        end
        -- now process non-file POSTs
        local post_args = ngx.req.get_post_args()
        local action = post_args.action
        if action == "system_reset_gui" then
                return sendcmd("resetgui")
        end
        if action == "system_reset_gui_full" then
                return sendcmd("resetguifull")
        end
        if action == "system_upgrade_gui" then
                return sendcmd("upgradegui_terminate")
        end
        if action == "system_install_specificapp" then
                proxy.set("rpc.system.modgui.app.sendcmd", "install_specificapp_"..getSupportedModel())
                proxy.apply()
                ngx.header.content_type = "application/json"
                ngx.print('{"success":"true"}')
                ngx.exit(ngx.HTTP_OK)
        end
        if action == "dismiss_acs_notice" then
                -- Slim variant of the upstream DISMISS_ACS_NOTICE: clears the
                -- ACS/CWMP "blocked update" reboot-reason shown in the header.
                local reboot_notice = { message = "uci.modgui.var.reboot_reason_msg" }
                content_helper.getExactContent(reboot_notice)
                if type(reboot_notice.message) == "string" and
                        (reboot_notice.message == "TIM ACS asked for firmware update. Go to Modgui Settings to allow this." or
                         reboot_notice.message:match("^ACS asked for firmware update from: .* Go to Modgui Settings to allow this%.$") ~= nil) then
                        proxy.set("uci.modgui.var.reboot_reason_msg", "")
                        proxy.apply()
                end
                ngx.header.content_type = "application/json"
                ngx.print('{"success":"true"}')
                ngx.exit(ngx.HTTP_OK)
        end
        if action == "system_remove_root" then
                return sendcmd("removeroot")
        end
        if action == "system_reset_config" then
                return sendcmd("resetconfig")
        end
        if action == "system_reset_cwmp" then
                return sendcmd("resetcwmp")
        end
        if action == "system_genBackup" then
                return genSysupgradeBackup()
        end
        if action == "checkver" then
                return sendcmd("checkver")
        end
        if action == "get_update_status" then
                local function value(path)
                        local result = proxy.get(path)
                        return result and result[1] and result[1].value
                end
                local status = {
                        state = value("rpc.system.modgui.executeCommand.state") or "Mapper Error",
                        new_version_text = value("uci.modgui.gui.new_ver"),
                }
                if status.state == "Error" then
                        local file = io.open("/tmp/command_log", "r")
                        if file then status.log = file:read("*a"); file:close() end
                end
                ngx.header.content_type = "application/json"
                ngx.print(require("dkjson").encode(status))
                return ngx.exit(ngx.HTTP_OK)
        end
        if action == "getVendor" then
                local raw_mac = post_args.mac and tostring(post_args.mac):gsub('_.*', '') or ""
                local safe_mac = raw_mac:match("^([%x:]+)$")
                if safe_mac and #safe_mac >= 6 then
                    local f = io.open("/tmp/mac_cache", "r")
                    local found = false
                    if f then
                        for l in f:lines() do
                            if l:find(safe_mac, 1, true) then
                                local vendor = l:match("^(.-)|") or l
                                ngx.print(vendor)
                                found = true
                                break
                            end
                        end
                        f:close()
                    end
                    if not found then
                        ngx.print("Unknown")
                    end
                end
                ngx.exit(ngx.HTTP_OK)
                return
        end
        if action == "debug_report" then

                local debuglog_path = "rpc.system.modgui.debuglog."

                proxy.set(debuglog_path.."start","1")
                proxy.apply()

                wait_for_completion(debuglog_path)

                local content = {
                        filename = debuglog_path.."filename",
                }

                -- Get transformer content
                content_helper.getExactContent(content)

                -- return exported data
                local fname = untaint(content.filename)
                if fname ~= "" then
                        ngx.header.content_disposition = "attachment; filename="..fname:match("([^/]+)$")
                        ngx.header.content_type = "application/octet-stream"
                        ngx.header.set_cookie = "fileDownload=true; Path=/"  -- the JS download code requires this cookie
                        local f = io.open(fname, "r")
                        ngx.print(f:read("*all"))
                        f:close()

                        os.remove(fname)

                        -- and we're done
                        ngx.exit(ngx.HTTP_OK)
                else
                        ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
                end
        end
end

local content = {
        gui_version = "rpc.system.modgui.gui_version",
        outdated_ver = "uci.modgui.gui.outdated_ver",
        new_ver = "uci.modgui.gui.new_ver",
        specific_app = "uci.modgui.app.specific_app",
        marketing_version = "uci.version.version.@version[0].marketing_version",
        telstra_gui = "uci.modgui.app.telstra_webui",
        fwversion_real = "uci.versioncusto.override.fwversion_override_real",
        activebank = "sys.banktable.activebank",
        passivebank = "sys.banktable.passivebank",
        bootedbank = "sys.banktable.booted",
        activeversion = "sys.banktable.activeversion",
        passiveversion = "sys.banktable.passiveversion",
        rip_key_B = "rpc.system.modgui.utility.rip_key_B",
}
content_helper.getExactContent(content)

local update_branch_option = {
        { "stable", T'Stable'},
        { "preview", T'Preview'},
}

local gui_skin_firstpage_page = {
        { "stats", T"Stats" },
        { "cards", T"Cards" },
}

if content.telstra_gui == "1" then
        table.insert(gui_skin_firstpage_page, { "telstra", T"Telstra" })
end

local gui_skin_option = {
        { "blue", T'Blue'},
        { "violet", T'Violet'},
        { "green", T'Green'},
        { "TIM" , T'Enhanced Tim'},
        { "dark-blue-unified", T"Dark Blue Unified UI"},
        { "Fritz", T'Fritz!Box'},
        { "dark-white_Fritz", T'Dark/White (Fritz!Box Based)'},
        { "dark-midnight_Fritz", T'Dark/Midnight (Fritz!Box Based)'},
        { "dark-red", T'Red Dark'},
}

local spoof_mode_enum = {
        { "disabled" , T"Comunicate real version to CWMP"},
        { "manual" , T"Set the version to comunicate to cwmp manually"},
}
local function validateVersionSpoofMode(value, object, key)

        local valid, msg = post_helper.getValidateInEnumSelect(spoof_mode_enum)

        if valid then
                local version_path="uci.versioncusto.override.fwversion_override"
                local _vr = proxy.get(version_path.."_real"); local version_real = (_vr and _vr[1] and _vr[1].value) or ""
                if value == "disabled" then
                        proxy.set(version_path, version_real)
                end
                proxy.apply()
        end

        return valid, msg
end

local mapParams = {
        update_branch = "uci.modgui.gui.update_branch",
        update_autoupgrade = "uci.modgui.gui.autoupgrade",
        update_autoupgrade_hour = "uci.modgui.gui.autoupgrade_hour",
        gui_skin = "uci.modgui.gui.gui_skin",
        gui_skin_firstpage = "uci.modgui.gui.firstpage",
        gui_randomcolor = "uci.modgui.gui.randomcolor",
        gui_alwaysadvanced = "uci.web.uiconfig.@uidefault.alwaysadvanced",
        gui_forcehttps = "uci.web.sessionmgr.@default.force_https",
        gui_animation = "uci.modgui.gui.gui_animation",
        disable_cwmp_update = "uci.modgui.var.disable_cwmp_update",
        modem_serial = "uci.env.var.serial",
        fwversion_override = "uci.versioncusto.override.fwversion_override",
        version_spoof_mode = "uci.modgui.var.version_spoof_mode",
        check_obp = "uci.modgui.var.check_obp"
}

local mapValid = {
        update_branch = post_helper.getValidateInEnumSelect(update_branch_option),
        update_autoupgrade = vB,
        update_autoupgrade_hour = gOV(post_helper.validateNonEmptyString),
        gui_skin = post_helper.getValidateInEnumSelect(gui_skin_option),
        gui_skin_firstpage = post_helper.getValidateInEnumSelect(gui_skin_firstpage_page),
        gui_randomcolor = vB,
        gui_alwaysadvanced = vB,
        gui_forcehttps = function(value)
                local ok, reason = https_support.validate(value)
                return ok, reason and T(reason)
        end,
        gui_animation = vB,
        disable_cwmp_update = vB,
        modem_serial = post_helper.validateNonEmptyString,
        fwversion_override = gOV(post_helper.validateNonEmptyString),
        version_spoof_mode = validateVersionSpoofMode,
        check_obp = vB
}

local modgui_settings, helpmsg = post_helper.handleQuery(mapParams, mapValid)
-- Update the live manager only from persisted, validated configuration.
-- A rejected form or another action must not enable a redirect in memory.
if ngx.req.get_method() == "POST" and ngx.req.get_post_args().action == "SAVE" then
        local saved = { force_https = "uci.web.sessionmgr.@default.force_https" }
        if content_helper.getExactContent(saved) then
                require("web.sessioncontrol").loadmgr("default").force_https = saved.force_https
        end
end
local visibility_changed = false

ngx.print(ui_helper.createHeader(T"GUI Settings & Utility", false, false))
ngx.print('\
<div class="modal-body update">\
');
ngx.print(ui_helper.createMessages(message_helper.popMessages()))

local basic = {
        span = {
                class = "span5"
        }
}
local upgrade_gui = {
        group = {
                class = "wait-for-reset"
        },
        button = {
                id = "btn-upgrade-gui",
                class = "custom-handler"
        }
}
local upload_gui_file = {
        button = {
                class = "import-gui custom-handler",
                id = "btn-import-gui"
        }
}
local upload_gui_fail = {
        alert = {
                class = "alert-error hide",
                id = "upgrade-gui-fail"
        }
}
local upload_gui_alert = {
        alert = {
                class = "alert-info hide",
                id = "upload-gui-alert"
        }
}
local updating = {
        alert = {
                class = "alert hide",
                id = "updating-msg"
        }
}
local autoupgrade = {
        input = {
                class = "monitor-changes",
        }
}
local autoupgrade_mon_1 = {
        group = {
                class ="monitor-update_autoupgrade monitor-1",
        },
        input = {
                class="span2",
                id = "update_autoupgrade_hour",
                style = "cursor:pointer;background-color:white;",
                value="03:00",
        }
}

local html = {}

html[#html + 1] = '<fieldset>'
html[#html + 1] = '<form class="form-horizontal" method="post" action="modals/modgui-modal.lp">'
html[#html + 1] = '<legend id="GUI_Upgrade_Legend">' .. T"Update GUI" .. '</legend>'
html[#html + 1] = '<span id="GUI-upgrade-option">'
html[#html + 1] = ui_helper.createAlertBlock(T"Update the GUI to the latest version available", info_box)
html[#html + 1] = ui_helper.createInputSelect(T"Update Branch", "update_branch", update_branch_option, modgui_settings["update_branch"])
html[#html + 1] = ui_helper.createSwitch(T"GUI Auto Update", "update_autoupgrade", modgui_settings["update_autoupgrade"],autoupgrade)
html[#html + 1] = ui_helper.createInputText(T"Update Hours", "update_autoupgrade_hour", modgui_settings["update_autoupgrade_hour"],autoupgrade_mon_1)
if content["outdated_ver"] == "1" then
        html[#html + 1] = ui_helper.createLabel(T"State", T"Update Found", basic)
        local new_ver_str = content["new_ver"] or ""
        local new_tag = new_ver_str:match("^v") and new_ver_str or ("v" .. new_ver_str)
        html[#html + 1] = ui_helper.createLabel(T"New Version", format("<a target=\"_blank\" href=https://github.com/NobodySan97/tch-nginx-gui/releases/tag/%s>%s</a>", new_tag, new_ver_str), basic)
        html[#html + 1] = ui_helper.createButton(T"Update GUI", T"Update", "icon-refresh", upgrade_gui)
else
        html[#html + 1] = ui_helper.createLabel(T"State", T"No Update found", basic)
        html[#html + 1] = ui_helper.createButton(T"Update GUI", T"Force Update", "icon-refresh", upgrade_gui)
end
html[#html + 1] = ui_helper.createButton(T"Check Update", T"Check Update", "icon-refresh", {
        button = { id = "btn-check-update", class = "custom-handler check_update" }
})
html[#html + 1] = '</span>'

html[#html + 1] = '</form><form class="form-horizontal" id="form-import-gui" method="post" action="modals/modgui-modal.lp?action=upgradeguifile" enctype="multipart/form-data">'
html[#html + 1] = '<div id="offline-upgrade-gui-div" class="control-group">'
html[#html + 1] = format('<label class="control-label">%s</label>', T"Offline GUI Update")
html[#html + 1] = '<div class="controls">'
html[#html + 1] = '<input type="file" name="upgradefile" id="file-upgradegui" accept=".bz2">&nbsp;'
html[#html + 1] = ui_helper.createSimpleButton(T"Update", "icon-shield", upload_gui_file)
html[#html + 1] = '</div></div>'
html[#html + 1] = '<div class="alert alert-info hide" id="upgrade-log"></div>'
html[#html + 1] = ui_helper.createAlertBlock(T"Update failed. Please try again.", upload_gui_fail)
html[#html + 1] = ui_helper.createAlertBlock(T"Uploading file. Please wait...", upload_gui_alert)
html[#html + 1] = ui_helper.createAlertBlock(T"Updating file. Please wait...", updating)
html[#html + 1] = '</form>'

html[#html + 1] = '<form class="form-horizontal" method="post" action="modals/modgui-modal.lp">'
html[#html + 1] = '<legend>'.. T"GUI Skin" ..'</legend>'
html[#html + 1] = ui_helper.createInputSelect(T"GUI Skin", "gui_skin", gui_skin_option, modgui_settings["gui_skin"])
html[#html + 1] = ui_helper.createInputSelect(T"GUI First Page", "gui_skin_firstpage", gui_skin_firstpage_page, modgui_settings["gui_skin_firstpage"])
html[#html + 1] = ui_helper.createSwitch(T"Random Color", "gui_randomcolor", modgui_settings["gui_randomcolor"])
local https_attributes
if not https_available and modgui_settings.gui_forcehttps ~= "1" then
        https_attributes = {switch = {class = "switch disabled"}}
end
html[#html + 1] = ui_helper.createSwitch(T"Force HTTPS to access the GUI", "gui_forcehttps",
        modgui_settings.gui_forcehttps, https_attributes, not https_available and T(https_reason) or helpmsg.gui_forcehttps)
html[#html + 1] = ui_helper.createSwitch(T"Always show advanced options", "gui_alwaysadvanced", modgui_settings["gui_alwaysadvanced"])
html[#html + 1] = ui_helper.createSwitch(T"GUI animations", "gui_animation", modgui_settings["gui_animation"])
html[#html + 1] = '</form>'

html[#html + 1] = '<form class="form-horizontal">'
html[#html + 1] = '<legend>' .. T"Dashboard Cards" .. '</legend>'
html[#html + 1] = ui_helper.createAlertBlock(T"Choose which cards are shown or hidden on the main dashboard, or use smart auto-detection for unconfigured services.", info_box)
html[#html + 1] = '<div class="control-group">'
html[#html + 1] = format('<label class="control-label">%s</label>', T"Manage Cards")
html[#html + 1] = '<div class="controls">'
html[#html + 1] = format('<a class="btn btn-primary modal-link" data-toggle="modal" data-remote="/modals/cards-manager-modal.lp" data-id="cards-manager-modal"><i class="fas fa-th-large"></i> %s</a>', T"Customize Dashboard Cards")
html[#html + 1] = '</div></div>'
html[#html + 1] = '</form>'

local marketing_major = tonumber((content.marketing_version or ""):match("^%d+"))
if content.specific_app ~= "" and (not marketing_major or marketing_major < 19) then

        local upload_specific_app = {
                button = {
                        class = "import-specificapp custom-handler",
                        id = "btn-import-specificapp"
                }
        }

        local upload_specificapp_fail = {
                alert = {
                        class = "alert-error hide",
                        id = "upgrade-specificapp-fail"
                }
        }
        local upload_specificapp_alert = {
                alert = {
                        class = "alert-info hide",
                        id = "upload-specificapp-alert"
                }
        }
        local install_specificapp = {
                group = {
                        class = "wait-for-reset"
                },
                button = {
                        id = "btn-install-specificapp",
                        class = "custom-handler"
                }
        }

        html[#html + 1] = '<form class="form-horizontal" id="form-import-specificapp" method="post" action="modals/modgui-modal.lp?action=installspecificapp" enctype="multipart/form-data">'
        html[#html + 1] = '<legend>'.. T"Specific App" ..'</legend>'
        html[#html + 1] = ui_helper.createAlertBlock(T"Specific App are package that adds additional function to the modem, like telnet support or some fix to default package", info_box)
        if content.specific_app == "1" then
                html[#html + 1] = ui_helper.createLabel(T"State", T"Specific App are already Installed", basic)
        else
                html[#html + 1] = ui_helper.createButton(T"Install", T"Install Specific App Online", "icon-refresh", install_specificapp)

                local device = getSupportedModel()

                html[#html + 1] = ui_helper.createAlertBlock(format(T"If you don't have connection, specific app can be downloaded here ( https://raw.githubusercontent.com/NobodySan97/gui-dev-build-auto/master/modular/upgrade-pack-specific%s.tar.bz2 ) and installed manually here.", device), info_box)
                html[#html + 1] = '<div class="control-group">'
                html[#html + 1] = format('<label class="control-label">%s</label>', T"Upload Specific App")
                html[#html + 1] = '<div class="controls">'
                html[#html + 1] = '<input type="file" name="specificapp_file" id="file-specificapp" accept=".bz2">&nbsp;'
                html[#html + 1] = ui_helper.createSimpleButton(T"Install", "icon-shield", upload_specific_app)
                html[#html + 1] = ui_helper.createAlertBlock(T"Uploading file. Please wait...", upload_specificapp_alert)
                html[#html + 1] = ui_helper.createAlertBlock(T"Update failed. Please try again.", upload_specificapp_fail)
                html[#html + 1] = '</div></div>'
                html[#html + 1] = '</form>'
        end

end

html[#html + 1] = '<form class="form-horizontal" method="post" action="modals/modgui-modal.lp">'
html[#html + 1] = '<legend>'.. T"CWMP Spoof Settings" ..'</legend>'
local info_box = {
        alert = {
                class = "alert alert-info",
        }
}
html[#html + 1] = ui_helper.createAlertBlock(T"Disable CWMP Update. Any firmware update from CWMP will be rejected and not flashed. "..
                        "Consider that CWMP that request a firmware update will keep requesting it until the update is actually installed. "..
                        "Autoconfiguration won't work. Manually set the version in the System Extra tab to spoof a version or upgrade the firmware.")
html[#html + 1] = ui_helper.createSwitch(T"Disable CWMP Update", "disable_cwmp_update", modgui_settings["disable_cwmp_update"])
html[#html + 1] = ui_helper.createAlertBlock(T"Change the Modem Serial. Consider that the modem serial is the Factory ID + Serial.", info_box)
html[#html + 1] = ui_helper.createInputText(T"Modem Serial", "modem_serial", modgui_settings["modem_serial"])
if not ( modgui_settings["fwversion_override"] == "" ) then
        html[#html + 1] = ui_helper.createAlertBlock(T"Disable override of Version Spoof at every GUI update, also usefull to permit CWMP to autoupdate the modem", info_box)
        html[#html + 1] = ui_helper.createInputSelect(T"Spoof Version Mode", "version_spoof_mode", spoof_mode_enum, modgui_settings["version_spoof_mode"])
        html[#html + 1] = ui_helper.createAlertBlock(T"Input the latest stock firmware version in this field to spoof it. This is necessary because if a newer version of the firmware is available on the ACS server, CWMPD will try to update the device and break remote monitoring from the “MyTIM” mobile app.", info_box)
        html[#html + 1] = ui_helper.createInputText(T"Version Set", "fwversion_override", modgui_settings["fwversion_override"], nil, helpmsg["fwversion_override"])
end
html[#html + 1] = '</form>'

html[#html + 1] = '<form class="form-horizontal" method="post" action="modals/modgui-modal.lp">'
html[#html + 1] = '<legend>' .. T"Advanced Reset" .. '</legend>'
local reset_gui = {
        group = {
                class = "wait-for-reset"
        },
        button = {
                id = "btn-reset-gui",
                class = "custom-handler"
        }
}
local reset_gui_full = {
        group = {
                class = "wait-for-reset"
        },
        button = {
                id = "btn-reset-gui-full",
                class = "custom-handler"
        }
}
local remove_root = {
        group = {
                class = "wait-for-reset"
        },
        button = {
                id = "btn-remove-root",
                class = "btn-danger custom-handler"
        }
}
local remove_config = {
        group = {
                class = "wait-for-reset"
        },
        button = {
                id = "btn-remove-config",
                class = "custom-handler"
        }
}
local reset_cwmp = {
        group = {
                class = "wait-for-reset"
        },
        button = {
                id = "btn-reset-cwmp",
                class = "custom-handler"
        }
}
local info_box = {
        alert = {
                class = "alert alert-info",
        }
}
local warning_box = {
        alert = {
                class = "alert alert-error",
        }
}
local resetting = {
        alert = {
                class = "alert hide",
                id = "resetting-msg"
        }
}
local resetting_gui_full = {
        alert = {
                class = "alert hide",
                id = "resetting-gui-full-msg"
        }
}
local unrooting = {
        alert = {
                class = "alert hide",
                id = "unrooting-msg"
        }
}
local resetting_config = {
        alert = {
                class = "alert hide",
                id = "config-resetting-msg"
        }
}

-- 1. Reset CWMP
html[#html + 1] = ui_helper.createAlertBlock(T"Reset CWMP database and force initial provisioning with ACS server.", info_box)
html[#html + 1] = ui_helper.createButton(T"Force CWMP provisioning", T"Reset CWMP", "icon-refresh", reset_cwmp)
html[#html + 1] = '<hr style="margin: 15px 0;" />'

-- 2. Restore Stock GUI (Preserve Config)
html[#html + 1] = ui_helper.createAlertBlock(T"Reset the modem to the firmware stock GUI. Network configuration and root SSH access will be preserved.", info_box)
html[#html + 1] = ui_helper.createAlertBlock(T"Resetting to default GUI, please wait...", resetting)
html[#html + 1] = ui_helper.createButton(T"Restore Stock GUI", T"Restore GUI", "icon-repeat", reset_gui)
html[#html + 1] = '<hr style="margin: 15px 0;" />'

-- 3. Restore Stock GUI & Factory Reset (Preserve Root SSH)
html[#html + 1] = ui_helper.createAlertBlock(T"Reset the modem to the firmware stock GUI and revert all configurations to factory defaults. Root SSH access will be preserved.", info_box)
html[#html + 1] = ui_helper.createAlertBlock(T"Resetting to default GUI and factory defaults, please wait...", resetting_gui_full)
html[#html + 1] = ui_helper.createButton(T"Restore Stock GUI & Factory Reset", T"Restore Stock & Reset", "icon-bolt", reset_gui_full)
html[#html + 1] = '<hr style="margin: 15px 0;" />'

-- 4. Reset Config (Keep Modded GUI)
html[#html + 1] = ui_helper.createAlertBlock(T"Reset all network and service configurations to factory defaults, while keeping the modded Custom GUI installed.", info_box)
html[#html + 1] = ui_helper.createAlertBlock(T"Resetting config to default, please wait...", resetting_config)
html[#html + 1] = ui_helper.createButton(T"Reset Configuration", T"Remove Config", "icon-refresh", remove_config)
html[#html + 1] = '<hr style="margin: 15px 0;" />'

-- 5. Factory Reset & Remove Root
html[#html + 1] = ui_helper.createAlertBlock(T"Complete factory reset: wipes the entire overlay partition, removing the modded GUI and permanent root access.", warning_box)
html[#html + 1] = ui_helper.createAlertBlock(T"Unrooting and reverting to factory defaults, please wait...", unrooting)
html[#html + 1] = ui_helper.createButton(T"Factory Reset & Remove Root", T"Remove Root", "icon-trash", remove_root)
html[#html + 1] = '</form>'

local import_backup = {
        button = {
                class = "import-backup custom-handler",
                id = "btn-import-backup"
        }
}
local upload_backup_alert = {
                alert = {
                        class = "alert-info hide",
                        id = "upload-backup-alert"
                }
        }
local restore_fail = {
        alert = {
                class = "alert-error hide",
                id = "restore-fail"
        }
}
local gen_backup = {
        button = {
                class = "custom-handler",
                id = "btn-gen-backup"
        }
}

html[#html + 1] = '<form class="form-horizontal" id="form-import-backup" method="post" action="modals/modgui-modal.lp?action=system_restoreBackup" enctype="multipart/form-data">'
html[#html + 1] = '<legend>'.. T"Advanced Restore & Backup" ..'</legend>'

html[#html + 1] = ui_helper.createAlertBlock(T"This will use OpenWRT backup and restore function insteand of the Technicolor function.", info_box)
html[#html + 1] = ui_helper.createButton(T"Backup ZIP", T"Generate", "icon-exchange", gen_backup)
html[#html + 1] = '<div class="control-group">'
html[#html + 1] = format('<label class="control-label">%s</label>', T"Upload Backup")
html[#html + 1] = '<div class="controls">'
html[#html + 1] = '<input type="file" name="sysupgrade_backup" id="file-restore" accept=".gz">&nbsp;'
html[#html + 1] = ui_helper.createSimpleButton(T"Restore", "icon-shield", import_backup)
html[#html + 1] = ui_helper.createAlertBlock(T"Uploading file. Please wait...", upload_backup_alert)
html[#html + 1] = ui_helper.createAlertBlock(T"Upload failed. Please try again.", restore_fail)
html[#html + 1] = '</div></div>'
html[#html + 1] = '</form>'

html[#html + 1] = '<form class="form-horizontal" method="post" action="modals/modgui-modal.lp">'
html[#html + 1] = '<legend>' .. T"Debug Report & Advanced settings" .. '</legend>'
local generate_debug_report = {
        button = {
                id = "btn-system-debug-report",
                class = "custom-handler"
        }
}
html[#html + 1] = ui_helper.createButton(T"Debug Zip", T"Generate", "icon-exchange", generate_debug_report)
html[#html + 1] = ui_helper.createAlertBlock(T"Force the device to always use bank_2 partition as booted partition and bank_1 as active but corrupted<br/>This will also ensure that overlay (configs/mods partition) of bank_1 is empty or just have the rooting script preloaded.<br/>This bank plan allow to use TFTP flashing, as a reliable recovery procedure in case we mess-up with the bank_2 overlay", info_box)
html[#html + 1] = ui_helper.createSwitch(T"OBP Check", "check_obp", modgui_settings["check_obp"])

html[#html + 1] = '<legend>'.. T"Bank Info" ..'</legend>'
if content["bootedbank"] and content["bootedbank"] ~= "" then
        html[#html + 1] = ui_helper.createLabel(T"Booted Bank", content["bootedbank"] , basic)
end
html[#html + 1] = ui_helper.createLabel(T"Active Bank", content["activebank"] , basic)
if content["activeversion"] == "Unknown" then
        html[#html + 1] = ui_helper.createLabel(T"Active Version", T"Firmware not present in this bank (OBP Recovery Plan)" , long_basic)
else
        html[#html + 1] = ui_helper.createLabel(T"Active Version", content["activeversion"] , long_basic)
end
html[#html + 1] = ui_helper.createLabel(T"Passive Bank", content["passivebank"] , basic)
if content["passiveversion"] == "Unknown" then
        html[#html + 1] = ui_helper.createLabel(T"Passive Version", T"Firmware not present in this bank" , long_basic)
else
        html[#html + 1] = ui_helper.createLabel(T"Passive Version", content["passiveversion"] , long_basic)
end

html[#html + 1] = '<legend>'.. T"Key Info" ..'</legend>'
html[#html + 1] = ui_helper.createLabel(T"Config decrypt key", content["rip_key_B"] , basic)
html[#html + 1] = '<legend>'.. T"Support & Donations" ..'</legend>'
html[#html + 1] = ui_helper.createLabel(T"Support Project", '<a target="_blank" class="btn btn-primary" href="https://ko-fi.com/nobodysan" style="background-color:#ff5e5b;border-color:#ff5e5b;color:#ffffff;"><i class="fa fa-coffee"></i> Support on Ko-fi</a>', basic)
html[#html + 1] = '</form>'
html[#html + 1] = '</fieldset>'
html[#html + 1] = '</div>'

ngx.print(html)

ngx.print('\
<script>\
(function() {\
  var refreshTimeOut = 5000;\
  var refreshDelay = 3000;\
  var target = $(".modal form").attr("action");\
\
  var timescroll_opt = {\
            theme: "android-ics light",\
            display: "bubble",\
            mode: "scroller",\
            headerText: false,\
            timeFormat: "HH:ii",\
            stepMinute: 5\
        };\
\
  $("#update_autoupgrade_hour").mobiscroll().time(timescroll_opt);\
  $("#update_autoupgrade_hour").on("change", function() {\
                $("#modal-no-change").fadeOut(300);\
        $("#modal-changes").delay(350).fadeIn(300);\
        }\
  );\
\
  function wait_for_webserver_running() {\
        $.ajax({ url: "/", timeout: refreshTimeOut })\
        .done(function(data) {\
          window.location.href = "/";\
        })\
        .fail(function() {\
          window.setTimeout(wait_for_webserver_running, refreshDelay);\
        });\
  };\
\
  function wait_for_webserver_down() {\
        $.ajax({ url: target, timeout: refreshTimeOut })\
        .done(function() {\
          window.setTimeout(wait_for_webserver_down, refreshDelay);\
        })\
        .fail(function() {\
          window.setTimeout(wait_for_webserver_running, refreshDelay);\
        });\
  };\
\
  function resetreboot(msg, msg_dst, action, customCallbackfunc) {\
        msg.removeClass("hide");\
        msg[0].scrollIntoView();\
        msg_dst.replaceWith(msg);\
        var callbackfunc = ( typeof customCallbackfunc === "function" ) && customCallbackfunc || wait_for_webserver_down;\
        if(callbackfunc == wait_for_webserver_down) modgui.clearKoInterval();\
        $.post(target,{action: action, CSRFtoken: $("meta[name=CSRFtoken]").attr("content")}, callbackfunc,"json");\
        return false;\
  };\
\
  function genericButtonFunction(headingText, processMsgText, ConfirmationDialogueText, resetIDName, btnID, callFunctionName, customCallBack) {\
        var heading = headingText;\
        var processMsg = processMsgText;\
        confirmationDialogue(ConfirmationDialogueText, heading);\
        $(document).off("click.genericConfirm");\
        $(document).on("click.genericConfirm", "#popUp #ok", function(e) {\
                   e.preventDefault();\
                   $(document).off("click.genericConfirm");\
                   $(".popUpBG, #popUp").remove();\
                   tch.removeProgress();\
                   tch.showProgress(processMsg);\
                   return resetreboot($(resetIDName), $(btnID), callFunctionName, customCallBack);\
        });\
        $(document).on("click.genericConfirm", "#popUp #cancel, .popUpBG", function(e) {\
                   e.preventDefault();\
                   $(document).off("click.genericConfirm");\
                   $(".popUpBG, #popUp").remove();\
        });\
        return false;\
  };\
\
  $("#btn-reset-gui").on("click", function() { return genericButtonFunction(\
                "');  ngx.print(T'Restore Stock GUI'); ngx.print('",\
                "');  ngx.print(T'Restoring Stock GUI, please wait...'); ngx.print('",\
                "');  ngx.print(T'Are you sure you want to restore the official stock GUI? Network configuration and root SSH access will be preserved.'); ngx.print('",\
                "#resetting-msg",\
                "#btn-reset-gui",\
                "system_reset_gui"\
        )}\
  );\
  $("#btn-reset-gui-full").on("click", function() { return genericButtonFunction(\
                "');  ngx.print(T'Restore Stock GUI & Factory Reset'); ngx.print('",\
                "');  ngx.print(T'Restoring Stock GUI and wiping configuration, please wait...'); ngx.print('",\
                "');  ngx.print(T'Are you sure you want to restore the official stock GUI and reset all configurations to factory defaults? Root SSH access will be preserved.'); ngx.print('",\
                "#resetting-gui-full-msg",\
                "#btn-reset-gui-full",\
                "system_reset_gui_full"\
        )}\
  );\
  $("#btn-remove-root").on("click", function() { return genericButtonFunction(\
                "');  ngx.print(T'Factory Reset & Remove Root'); ngx.print('",\
                "');  ngx.print(T'Wiping overlay and reverting to factory defaults, please wait...'); ngx.print('",\
                "');  ngx.print(T"Are you sure you want to perform a complete factory reset? <br/><strong>This will wipe all custom files and remove root SSH access permanently.</strong>"); ngx.print('",\
                "#unrooting-msg",\
                "#btn-remove-root",\
                "system_remove_root"\
        )}\
  );\
  $("#btn-remove-config").on("click", function() { return genericButtonFunction(\
                "');  ngx.print(T'Reset Configuration'); ngx.print('",\
                "');  ngx.print(T'Resetting configuration to defaults, please wait...'); ngx.print('",\
                "');  ngx.print(T"Are you sure you want to reset the configuration? Network settings will return to factory defaults, but the Custom GUI will remain installed."); ngx.print('",\
                "#config-resetting-msg",\
                "#btn-remove-config",\
                "system_reset_config"\
        )}\
  );\
  $("#btn-reset-cwmp").on("click", function() { return genericButtonFunction(\
                "');  ngx.print(T'Reset CWMP'); ngx.print('",\
                "');  ngx.print(T'Resetting...'); ngx.print('",\
                "');  ngx.print(T"Are you sure you want to reset CWMP db of this modem? <br/><strong> This will force the first-time boot provisioning with ACS server that can fail on an already provisioned modem.</strong>"); ngx.print('",\
                "#btn-reset-cwmp",\
                "#btn-reset-cwmp",\
                "system_reset_cwmp",\
                tch.removeProgress\
        )}\
  );\
\
  var schedulReload = false;\
\
  $("#gui_skin").on("change", function() {\
        var theme = $(this).val();\
        if ( theme.indexOf("Fritz") === -1 ) {\
                var restyled = theme+"/style.css";\
                modgui.freshStyle(restyled);\
        }\
        if ( theme.indexOf("Fritz") != -1 || theme.indexOf("unified") != -1) {\
                if($(\'#gui_skin_firstpage option[value="cards"]\').is(":selected")) $("#gui_skin_firstpage").val("stats");\
                $(\'#gui_skin_firstpage option[value="cards"]\').attr("disabled","disabled");\
        } else {\
                $(\'#gui_skin_firstpage option[value="cards"]\').removeAttr("disabled");\
        }\
        schedulReload = true;\
  });\
\
  $("#btn-gen-backup").on("click", function() {\
    $.fileDownload(target, {\
      httpMethod: "POST",\
      data: new Array({ name : "action", value : "system_genBackup" },\
                      { name : "CSRFtoken", value : $("meta[name=CSRFtoken]").attr("content") }),\
      prepareCallback: function() {\
                tch.showProgress("');  ngx.print(T"Generating backup in background..."); ngx.print('");\
      },\
      successCallback: function() {\
                tch.removeProgress();\
      }\
    });\
    return false;\
  });\
\
  $("#gui_forcehttps,#gui_alwaysadvanced").on("change", function() {\
        schedulReload = true;\
  });\
\
  $("#save-config").on("click", function() {\
        if ( schedulReload ) {\
                schedulReload = true;\
                setTimeout(function() {window.location.reload(!0);},1000);\
        }\
  });\
\
  $(document).on("click", "#cancel", function() {\
          tch.removeProgress();\
  });\
\
  modgui.linkCheckUpdate();\
  $("#btn-upgrade-gui").on("click", function() {\
        modgui.postAction("system_upgrade_gui",1);\
  });\
\
  $(".import-gui").on("click", function() {\
        var nofile_msg = $("#upgrade-gui-fail");\
        var wrongext_msg = $("#upgrade-gui-fail");\
        nofile_msg.addClass("hide");\
        if ($("#file-upgradegui").val() == "") {\
          nofile_msg.removeClass("hide");\
          nofile_msg[0].scrollIntoView();\
          return false;\
        };\
\
        var validExtensions = [\'bz2\'];\
        var fileName = $("#file-upgradegui").val();\
\
        var fileNameExt = fileName.substr(fileName.lastIndexOf(".") + 1);\
        if ($.inArray(fileNameExt, validExtensions) == -1){\
                wrongext_msg.removeClass("hide");\
        wrongext_msg[0].scrollIntoView();\
        return false;\
        };\
        var fileSize = $("#file-upgradegui")[0].files[0].size;\
        var importing_msg = $("#upload-gui-alert");\
        var _this = $(this).parents(".control-group");\
        importing_msg.removeClass("hide");\
        importing_msg[0].scrollIntoView();\
\
        $.fileUpload($("#form-import-gui"), {\
          params: { CSRFtoken: $("meta[name=CSRFtoken]").attr("content") },\
          completeCallback: function(form, response) {\
                if (response.success) {\
                  modgui.postAction("system_upgrade_gui",1);\
                } else {\
                  importing_msg.addClass("hide");\
                  $("#upgrade-gui-fail").removeClass("hide");\
                }\
          }\
        });\
        return false;\
  });\
\
  $("#btn-install-specificapp").on("click", function() {\
        modgui.postAction("system_install_specificapp",1);\
  });\
\
  $(".import-specificapp").on("click", function() {\
        var nofile_msg = $("#upgrade-specificapp-fail");\
        var wrongext_msg = $("#upgrade-specificapp-fail");\
        nofile_msg.addClass("hide");\
        if ($("#file-specificapp").val() == "") {\
          nofile_msg.removeClass("hide");\
          nofile_msg[0].scrollIntoView();\
          return false;\
        };\
\
        var validExtensions = [\'bz2\'];\
        var fileName = $("#file-specificapp").val();\
\
        var fileNameExt = fileName.substr(fileName.lastIndexOf(".") + 1);\
        if ($.inArray(fileNameExt, validExtensions) == -1){\
                wrongext_msg.removeClass("hide");\
        wrongext_msg[0].scrollIntoView();\
        return false;\
        };\
        var fileSize = $("#file-specificapp")[0].files[0].size;\
        var importing_msg = $("#upload-specificapp-alert");\
        var _this = $(this).parents(".control-group");\
        importing_msg.removeClass("hide");\
        importing_msg[0].scrollIntoView();\
\
        $.fileUpload($("#form-import-specificapp"), {\
          params: { CSRFtoken: $("meta[name=CSRFtoken]").attr("content") },\
          completeCallback: function(form, response) {\
                if (response.success) {\
                  modgui.postAction("system_install_specificapp",1);\
                } else {\
                  importing_msg.addClass("hide");\
                  $("#upgrade-specificapp-fail").removeClass("hide");\
                }\
          }\
        });\
        return false;\
  });\
\
$(".import-backup").on("click", function() {\
        var nofile_msg = $("#restore-fail");\
        var wrongext_msg = $("#restore-fail");\
        nofile_msg.addClass("hide");\
        if ($("#file-restore").val() == "") {\
          nofile_msg.removeClass("hide");\
          nofile_msg[0].scrollIntoView();\
          return false;\
        };\
\
        var validExtensions = [\'gz\'];\
        var fileName = $("#file-restore").val();\
\
        var fileNameExt = fileName.substr(fileName.lastIndexOf(".") + 1);\
        if ($.inArray(fileNameExt, validExtensions) == -1){\
                wrongext_msg.removeClass("hide");\
        wrongext_msg[0].scrollIntoView();\
        return false;\
        };\
        var fileSize = $("#file-restore")[0].files[0].size;\
        var importing_msg = $("#upload-backup-alert");\
        var _this = $(this).parents(".control-group");\
        importing_msg.removeClass("hide");\
        importing_msg[0].scrollIntoView();\
\
        $.fileUpload($("#form-import-backup"), {\
          params: { CSRFtoken: $("meta[name=CSRFtoken]").attr("content") },\
          completeCallback: function(form, response) {\
                if (response.success) {\
                  importing_msg.addClass("hide");\
                  tch.showProgress("');  ngx.print(T'Rebooting'); ngx.print('...");\
                  modgui.clearKoInterval(); \
                  wait_for_webserver_down(); \
                } else {\
                  importing_msg.addClass("hide");\
                  $("#restore-fail").removeClass("hide");\
                }\
          }\
        });\
        return false;\
  });\
  $("#btn-system-debug-report").on("click", function() {\
    $.fileDownload(target, {\
      httpMethod: "POST",\
      data: new Array({ name : "action", value : "debug_report" },\
                      { name : "CSRFtoken", value : $("meta[name=CSRFtoken]").attr("content") }),\
      prepareCallback: function() {\
                tch.showProgress(\'');  ngx.print(T"Generating report in background..."); ngx.print('\');\
      },\
      successCallback: function() {\
                location.reload();\
      }\
    });\
    return false;\
  });\
  var fwversion_real = "'); ngx.print(content.fwversion_real); ngx.print('";\
  $("#version_spoof_mode").on("change", function() {\
        if ( $(this).val() == "manual" ) {\
          $("#fwversion_override").prop("disabled", false);\
        } else {\
    if ( $(this).val() == "disabled" ) {\
                $("#fwversion_override").val(fwversion_real);\
          }\
          $("#fwversion_override").prop("disabled", true);\
        }\
  });\
  if ( $("#version_spoof_mode").val() == "manual" ) {\
    $("#fwversion_override").prop("disabled", false);\
  } else {\
    $("#fwversion_override").prop("disabled", true);\
  }\
');

if ngx.req.get_uri_args().action and ngx.req.get_uri_args().action == "manualguiupgrade" then
        ngx.print('$("#GUI_Upgrade_Legend")[0].scrollIntoView();');
end
ngx.print('\
})();\
</script>\
');  ngx.print(ui_helper.createFooter())   ngx.print('\
');
