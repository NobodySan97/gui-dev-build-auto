--pretranslated: do not change this file
 
-- Localization
gettext.textdomain('webui-core')

local proxy = require("datamodel")
local ui_helper = require("web.ui_helper")
local content_helper = require("web.content_helper")
local ipairs = ipairs
local match, format, lower = string.match, string.format, string.lower

local function getValue(path)
  local result = proxy.get(path)
  return result and result[1] and result[1].value or ""
end

local function hasPath(path)
  local result = proxy.get(path)
  return result and result[1] ~= nil
end

local ports = {"eth0", "eth1", "eth2", "eth3"}
local first_column_txt = {T"Port 1", T"Port 2", T"Port 3", T"Port 4"}

-- resetting traffic counters button
local clear_network_stats = {
  controls = {
    class = "clear_network_stats"
  },
  button = {
    ["data-name"] = "stats_reset",
    ["data-value"] = "RESET"
  }
}

local isEth4Included = false
local sfp_enabled = getValue("uci.env.rip.sfp") == "1"
local has_gpon = hasPath("rpc.optical.Interface.1.Status") or hasPath("rpc.gpon.ploam.state")
if not sfp_enabled then
  local eth4 = proxy.getPN("sys.class.net.@eth4.", true)
  if eth4 and next(eth4) then
    ports[#ports+1] = "eth4"
    first_column_txt[#first_column_txt+1] = "Port 5"
    isEth4Included = true
  end
else
  if getValue("uci.ethernet.globals.eth4lanwanmode") == "0" then
    ports[4] = "eth4"
    isEth4Included = true
  end
end
if sfp_enabled or has_gpon then
  ports[#ports+1] = "gpon"
  first_column_txt[#first_column_txt+1] = "GPON"
end
local eth = {}
for k,v in ipairs(ports) do
  if v == "gpon" then
    local base_path = "rpc.optical.Interface.1."
    eth["op" .. v] = base_path .. "Status"
    eth["sp" .. v] = base_path .. "OpticalSignalLevel"
  else
    local base_path = "sys.class.net.@" .. v
    eth["op" .. v] = base_path .. ".operstate"
    eth["sp" .. v] = base_path .. ".speed"
  end
end
content_helper.getExactContent(eth)

local ports_speed = {}
local speed = proxy.get("sys.eth.port.") or {}
for _,f in ipairs(speed) do
  if f["param"] == "speed"  and f["value"] ~= "" then
    ports_speed [match(f["path"], "sys.eth.port.@(eth%d)")] = f["value"]
  end
end

local portAttr = {
  socket = {
    class = "socket-form"
  }
}
  ngx.print('\
');  ngx.print(ui_helper.createHeader(T"Diagnostics", false, false, 2) ); ngx.print('\
<div class="modal-body update">\
');  
  local lp = require("web.lp")
  lp.setpath("/www/snippets/")
  lp.include("tabs-diagnostics.lp")
  ngx.print('\
');  
-- dummy form so that refresh button knows which page to reload, keep it
  ngx.print('\
  <form class="form-horizontal" method="post" action="modals/diagnostics-network-modal.lp">\
  </form>\
  <fieldset id="diagnostics-network-tab">\
	<fieldset>\
	<legend>');  ngx.print( T"Ports State" ); ngx.print('</legend>\
	<div class="control-group">\
      <div class="controls">\
      ');  for k, v in ipairs(ports) do  ngx.print('\
        <div class="span2 simple-desc">\
        ');  
          if isEth4Included and match(v, "eth") and getValue("uci.ethernet.port.@"..v..".wan") == "1" then
	    portAttr.socket.class = "red socket-form"
	  elseif match(v, "gpon") then
	    portAttr.socket.class = "red socket-form"
	  else
	    portAttr.socket.class = "yellow socket-form"
          end
          ngx.print(ui_helper.createSwitchPort(tostring(k), lower(eth["op" .. v] or ""), eth["sp" .. v], portAttr))
          -- todo replace speed with actual speed
          if eth["op" .. v] == "up" then
	    ngx.print('\
	    <p class="socket-legend" id = "');  ngx.print(v); ngx.print('">');  ngx.print( T"Connected" ); ngx.print('</p>\
            ');  if(ports_speed[v]) then  ngx.print('\
              <p class="socket-legend">(');  ngx.print(format(T"%s Mbps", ports_speed[v]) ); ngx.print(')</p>\
            ');  end  ngx.print('\
	    ');  elseif eth["op" .. v] == "Up" then  ngx.print('\
              <p class="socket-legend" id = "');  ngx.print(v); ngx.print('">');  ngx.print( T"Connected-SFP" ); ngx.print('</p>\
              ');  if(ports_speed[v]) then  ngx.print('\
                <p class="socket-legend">(');  ngx.print( format(T"%s Mbps", ports_speed[v]) ); ngx.print(')</p>\
              ');  end   ngx.print('\
            ');  else   ngx.print('\
              <p class="socket-legend grayLight" id = "');  ngx.print(v); ngx.print('">');  ngx.print( T"Not connected" ); ngx.print('</p>\
            ');  end   ngx.print('\
          </div>\
        ');  end   ngx.print('\
      </div>\
    </div>\
	</fieldset>\
	<fieldset>\
    <legend class="networkStat">');  ngx.print( T"Network Statistics" ); ngx.print('</legend>\
    ');  
      local wireless = proxy.get("rpc.wireless.ssid.") or {}
      local wirelessindex = content_helper.convertResultToObject("rpc.wireless.ssid.@.",wireless) or {}
      for _,v in ipairs(wirelessindex) do
        ports[#ports+1] = v.paramindex
		local band = v.radio and getValue("rpc.wireless.radio.@" .. v.radio .. ".supported_frequency_bands") or ""
		local band_label = band ~= "" and ("(" .. band .. ")") or ""
		first_column_txt[#first_column_txt+1] = (v.ssid or v.paramindex) .. band_label
      end

local post_content
if ngx.var.request_method == "POST" then
  post_content = ngx.req.get_post_args()
  local base_path
  if post_content["stats_reset"] == "RESET" then
    for _,v in ipairs(ports) do
    if string.match(v, "wl") then
      base_path = "rpc.wireless.ssid.@"..v..".stats.reset"
    elseif match(v, "gpon") then
      base_path = "rpc.optical.Interface.1.Stats.reset"
    else
      base_path = "sys.class.net.@"..v..".statistics.reset"
    end
    proxy.set(base_path, "true")
  end
end
local action = ngx.req.get_post_args().action
  for i,v in ipairs(ports) do
    if action == v and string.match(v,"eth") then
      local success = proxy.set("sys.class.net.@"..v..".statistics.reset", "1")
    elseif action == v and string.match(v,"wl") then
      local success = proxy.set("rpc.wireless.ssid.@"..v..".stats.reset", "1")
    elseif action == v and string.match(v,"gpon") then
      local success = proxy.set("rpc.optical.Interface.1.Stats.reset", "1")
    elseif action == "resetall" then
      for x,y in ipairs(ports) do
        if string.match(y, "wl") then
          proxy.set("rpc.wireless.ssid.@"..y..".stats.reset", "1")
        elseif match(y, "eth") then
          proxy.set("sys.class.net.@"..y..".statistics.reset", "1")
        elseif match(y, "gpon") then
          proxy.set("rpc.optical.Interface.1.Stats.reset", "1")
        end
      end
    end
    if success then
      proxy.apply();
    end
  end
end

local base_path
local param = {"rx_bytes", "rx_bytes", "tx_bytes", "rx_packets", "tx_packets", "rx_errors", "tx_errors"}
local gpon_param = {"BytesReceived", "BytesReceived", "BytesSent", "PacketsReceived", "PacketsSent", "ErrorsReceived", "ErrorsSent"}
local datarows ={}
for k,v in ipairs(ports) do
  if k == 10 then
    break
  end
  datarows[k]={}
  if string.match(v, "wl") then
    base_path = "rpc.wireless.ssid.@" .. v ..".stats."
  elseif match(v, "gpon") then
    base_path = "rpc.optical.Interface.1.Stats."
  else
    base_path = "sys.class.net.@" .. v .. ".statistics."
  end
  if match(v, "gpon") then
    for kk,vv in ipairs(gpon_param) do
      datarows[k][kk] = base_path .. vv
    end
  else
    for kk,vv in ipairs(param) do
      datarows[k][kk] = base_path .. vv
    end
  end
  content_helper.getExactContent(datarows[k])
  datarows[k][8] = ui_helper.createSimpleButton(T"Reset Stats", nil, {controls = {class = string.format("clear_network_stats_%s",v)}, button = {["data-name"] = "action", ["data-value"] = string.format("%s",v),}})
end

  --re-write the first column
  for k,v in ipairs(first_column_txt) do
    datarows[k][1] = v
  end

  local full_array={}
  for i=1, 7 do
    full_array[i]={}
    for z=1, 7 do
      full_array[i][z]="data"..z
    end
  end

  --Column Names
  local columns ={}
  for i=1, 8 do
    columns[i]={}
  end
  columns[1]["header"] = T"Interface"
  columns[2]["header"] = T"Rx Bytes"
  columns[3]["header"] = T"Tx Bytes"
  columns[4]["header"] = T"Rx Packets"
  columns[5]["header"] = T"Tx Packets"
  columns[6]["header"] = T"Rx Errors"
  columns[7]["header"] = T"Tx Errors"
  columns[8]["header"] = T"Reset"
  local options = { tableid = "networkstats", canEdit = false, canAdd = false, canDelete = false }
  -- table that shows the Statistics data
  ngx.print(ui_helper.createTable(columns, datarows, options))
    ngx.print('\
  <center>\
    ');  ngx.print( ui_helper.createSimpleButton(T"Reset Stats", "icon-bolt", clear_network_stats)); ngx.print('\
  </center>\
  </fieldset>\
  </fieldset>\
</div>\
');  ngx.print(ui_helper.createFooter() ); ngx.print('\
');
